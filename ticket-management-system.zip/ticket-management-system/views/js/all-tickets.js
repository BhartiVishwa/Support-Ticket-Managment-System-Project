const currentPage = 1;
const limit = 5;

const fetchUserInfo = async () => {
  const res = await fetch("http://localhost:5000/auth/me", {
    credentials: "include",
  });
  if (!res.ok || (await res.json()).role !== "agent") {
    alert("Access Denied");
    window.location.href = "dashboard.html";
    return;
  }
  fetchTickets();
};

const fetchTickets = async () => {
  const search = document.getElementById("search")?.value || "";
  const status = document.getElementById("filterStatus")?.value || "";
  const priority = document.getElementById("filterPriority")?.value || "";

  const url = `http://localhost:5000/tickets?search=${search}&status=${status}&priority=${priority}&page=${currentPage}&limit=${limit}`;

  const res = await fetch(url, {
    credentials: "include",
  });
  if (!res.ok) {
    alert("Error fetching tickets");
    return;
  }
  const data = await res.json();
  renderTickets(data.tickets);
  renderPagination(data.totalPages);
};

const renderTickets = (tickets) => {
  const tbody = document.querySelector("#ticketTable tbody");
  tbody.innerHTML = "";
  tickets.forEach((ticket) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${ticket.title}</td>
      <td>${ticket.description}</td>
      <td>${ticket.priority}</td>
      <td>
        <select onchange="updateStatus('${ticket._id}', this.value)">
          <option value="open" ${ticket.status === "open" ? "selected" : ""}>Open</option>
          <option value="in-progress" ${ticket.status === "in-progress" ? "selected" : ""}>In Progress</option>
          <option value="resolved" ${ticket.status === "resolved" ? "selected" : ""}>Resolved</option>
          <option value="closed" ${ticket.status === "closed" ? "selected" : ""}>Closed</option>
        </select>
      </td>
      <td>${ticket.createdBy ? ticket.createdBy.name : "N/A"}</td>
      <td>
        <button onclick="deleteTicket('${ticket._id}')">Delete</button>
      </td>
    `;
    tbody.appendChild(row);
  });
};

const renderPagination = (totalPages) => {
  const paginationDiv = document.getElementById("pagination");
  paginationDiv.innerHTML = "";
  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    btn.className = i === currentPage ? "active-page" : "";
    btn.onclick = () => {
      window.currentPage = i;
      fetchTickets();
    };
    paginationDiv.appendChild(btn);
  }
};

const updateStatus = async (ticketId, newStatus) => {
  const res = await fetch(`http://localhost:5000/tickets/${ticketId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ status: newStatus }),
    credentials: "include",
  });
  if (res.ok) {
    fetchTickets();
  } else {
    alert("Error updating ticket");
  }
};

const deleteTicket = async (ticketId) => {
  const res = await fetch(`http://localhost:5000/tickets/${ticketId}`, {
    method: "DELETE",
    credentials: "include",
  });
  if (res.ok) {
    fetchTickets();
  } else {
    alert("Error deleting ticket");
  }
};

document.getElementById("applyFilters")?.addEventListener("click", () => {
  window.currentPage = 1;
  fetchTickets();
});

fetchUserInfo();