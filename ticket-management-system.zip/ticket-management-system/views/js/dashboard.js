window.currentPage = 1;
const limit = 1000;

const fetchUserInfo = async () => {
  const res = await fetch("http://localhost:5000/auth/me", {
    credentials: "include",
  });
  if (!res.ok) {
    document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 GMT";
    window.location.href = "login.html";
    return;
  }
  const data = await res.json();
  window.userRole = data.role;
  window.userId = data.id;
  renderUserInfo();
  renderTicketForm();
  fetchTickets();
};

const renderUserInfo = () => {
  const userInfoDiv = document.getElementById("userInfo");
  userInfoDiv.innerHTML = `
    <p>Welcome, <strong>${
      window.userRole.charAt(0).toUpperCase() + window.userRole.slice(1)
    }</strong>!</p>
    ${
      window.userRole === "agent"
        ? '<p><a href="all-tickets.html">View All Tickets</a></p>'
        : ""
    }
    ${
      window.userRole === "admin"
        ? '<button class="admin-button"><a href="admin.html">Go to Admin Panel</a></button>'
        : ""
    }
  `;
};

const renderTicketForm = () => {
  if (window.userRole === "user") {
    document.getElementById("ticketFormContainer").innerHTML = `
      <form id="ticketForm">
        <input type="text" id="title" placeholder="Title" required />
        <textarea id="description" placeholder="Description" required></textarea>
        <select id="priority">
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <button type="submit">Create Ticket</button>
      </form>
    `;
    document
      .getElementById("ticketForm")
      .addEventListener("submit", async (e) => {
        e.preventDefault();
        const ticket = {
          title: document.getElementById("title").value,
          description: document.getElementById("description").value,
          priority: document.getElementById("priority").value,
        };
        const res = await fetch("http://localhost:5000/tickets", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(ticket),
          credentials: "include",
        });
        if (res.ok) {
          alert("Ticket created successfully");
          fetchTickets();
        } else {
          alert("Error creating ticket");
        }
      });
  }
};

const fetchTickets = async () => {
  const search = document.getElementById("search")?.value || "";
  const status = document.getElementById("filterStatus")?.value || "";
  const priority = document.getElementById("filterPriority")?.value || "";

  let url =
    window.userRole === "user"
      ? `http://localhost:5000/tickets/my`
      : `http://localhost:5000/tickets?search=${search}&status=${status}&priority=${priority}&page=${window.currentPage}&limit=${limit}`;

  const res = await fetch(url, {
    credentials: "include",
  });
  if (!res.ok) {
    alert("Error fetching tickets");
    return;
  }
  const data = await res.json();
  const tickets = window.userRole === "user" ? data : data.tickets;
  const totalPages = data.totalPages || 1;
  renderTickets(tickets);
  renderPagination(totalPages);
};

const renderTickets = (tickets) => {
  const tbody = document.querySelector("#ticketTable tbody");
  tbody.innerHTML = "";
  tickets.forEach((ticket) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${ticket.title}</td>
      <td>${ticket.description}</td>
      <td>${ticket.priority}</td>
      <td>
        <select onchange="updateStatus('${ticket._id}', this.value)">
          <option value="open" ${
            ticket.status === "open" ? "selected" : ""
          }>Open</option>
          <option value="in-progress" ${
            ticket.status === "in-progress" ? "selected" : ""
          }>In Progress</option>
          <option value="resolved" ${
            ticket.status === "resolved" ? "selected" : ""
          }>Resolved</option>
          <option value="closed" ${
            ticket.status === "closed" ? "selected" : ""
          }>Closed</option>
        </select>
      </td>
      <td>${ticket.createdBy ? ticket.createdBy.name : "N/A"}</td>
      <td>
      <div style="display: flex; gap: 10px;">
        <button onclick="deleteTicket('${ticket._id}')">Delete</button>
        <button onclick="editTicket('${ticket._id}')">Edit</button>
        </div>
        </td>
    `;
    tbody.appendChild(row);
  });
};

const renderPagination = (totalPages) => {
  const paginationDiv = document.getElementById("pagination");
  paginationDiv.innerHTML = "";
  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    btn.className = i === window.currentPage ? "active-page" : "";
    btn.onclick = () => {
      window.currentPage = i;
      fetchTickets();
    };
    paginationDiv.appendChild(btn);
  }
};

const updateStatus = async (ticketId, newStatus) => {
  const res = await fetch(`http://localhost:5000/tickets/${ticketId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ status: newStatus }),
    credentials: "include",
  });
  if (res.ok) {
    fetchTickets();
  } else {
    alert("Error updating ticket");
  }
};

const deleteTicket = async (ticketId) => {
  const res = await fetch(`http://localhost:5000/tickets/${ticketId}`, {
    method: "DELETE",
    credentials: "include",
  });
  if (res.ok) {
    fetchTickets();
  } else {
    alert("Error deleting ticket");
  }
};

window.editTicket = async (ticketId) => {
  console.log(ticketId);
  // Fetch the ticket details (optional, if you want to prefill)
  const res = await fetch(`http://localhost:5000/tickets/${ticketId}`, {
    credentials: "include",
  });
  if (!res.ok) {
    alert("Error fetching ticket details");
    return;
  }
  const ticket = await res.json();

  // Show a prompt for editing (for simplicity, use prompt; you can use a modal for better UX)
  const newTitle = prompt("Edit Title:", ticket.title);
  if (newTitle === null) return; // Cancelled

  const newDescription = prompt("Edit Description:", ticket.description);
  if (newDescription === null) return; // Cancelled

  const newPriority = prompt(
    "Edit Priority (low, medium, high):",
    ticket.priority
  );
  if (newPriority === null) return; // Cancelled

  // Send update request
  const updateRes = await fetch(`http://localhost:5000/tickets/${ticketId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      title: newTitle,
      description: newDescription,
      priority: newPriority,
    }),
    credentials: "include",
  });

  if (updateRes.ok) {
    fetchTickets();
    alert("Ticket updated!");
  } else {
    alert("Error updating ticket");
  }
};

document.getElementById("applyFilters")?.addEventListener("click", () => {
  window.currentPage = 1;
  fetchTickets();
});

fetchUserInfo();
