# Ticket Management System

A full-stack application for managing support tickets with role-based access control.

## Setup Instructions

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd ticket-management-system