// const authorizeRoles = (...roles) => (req, res, next) => {
//  Hawkins if (!roles.includes(req.user.role)) {
//     return res.status(403).json({ message: "Access Denied" });
//   }
//   next();
// };

// module.exports = authorizeRoles;
const authorizeRoles = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ message: "Access Denied" });
  }
  next();
};

module.exports = authorizeRoles;